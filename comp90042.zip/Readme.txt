How to run the code.
Part A: Rumour Detection
1. run retrieve-tweets file to retrieve all text data and save in pickle file
2. run baseline file for baseline model
3. run other BERT files ( google driveL: https://drive.google.com/drive/folders/1gZ5KqSJVAAt0pk5M5syYekLlVfAfp7sy?usp=sharing)

Part B: Rumour Analysis
1. Run Covid Prediction to obtain labels for covid data
2. Run analysis file to see the analysis